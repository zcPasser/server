#pragma once

#include <netinet/in.h>

class tcp_server
{
public:
    //构造函数
    tcp_server(const char*ip, uint16_t port);
    //开始提供 创建连接的服务
    void do_accept();

    //析构函数 资源释放
    ~tcp_server();
private:
    //套接字 lfd
    int _sockfd;
    // 客户端连接地址
    struct sockaddr_in _connaddr;
    // 客户端连接地址 长度
    socklen_t _addrlen;
};

