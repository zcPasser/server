#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <strings.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>

#include "tcp_server.h"

void lars_hello()
{
    std::cout << "lars Hello!" << std::endl;
}

//构造函数
tcp_server::tcp_server(const char*ip, uint16_t port)
{
    // 优化：0
    // 0-忽略一些信号 SIGHUP SIGPIPE
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR)
    {
        // fprintf(stderr, "signal ignore SIGHUP failed\n");
        perror("signal ignore SIGHUP");
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    {
        // fprintf(stderr, "signal ignore SIGPIPE failed\n");
        perror("signal ignore SIGPIPE");
    }
    // 1-创建socket
    // SOCK_CLOEXEC：连接关闭时，释放资源。
    _sockfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (_sockfd == -1)
    {
        fprintf(stderr, "tcp::server : socket()\n");
        exit(1);
    }
    // 2-初始化服务器地址
    struct sockaddr_in server_addr;
    // 清空
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_aton(ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);
    // 优化：2.5
    // 2.5-设置 socket 可以重复监听
    int reused_addr = 1;
    if(setsockopt(_sockfd, SOL_SOCKET, SO_REUSEADDR, &reused_addr, sizeof(reused_addr)) < 0)
    {
        // fprintf(stderr, "setsockopt reused_addr failed\n");
        perror("setsockopt reused_addr");        
    }
    // 3-绑定端口
    if (bind(_sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("bind");
        exit(1);
    }
    // 4-监听
    if (listen(_sockfd, 500) == -1)
    {
        fprintf(stderr, "bind error\n");
        exit(1);
    }
}

//开始提供 创建连接的服务
void tcp_server::do_accept()
{
    int connfd;
    // while(1)
    while(true)
    {
        // 1-accept
        connfd = accept(_sockfd, (struct sockaddr*)&_connaddr, &_addrlen);
        if(connfd == -1)
        {
            // 中断错误，合法。
            if(errno == EINTR)
            {
                fprintf(stderr, "accept: errno == EINTR\n");
                continue;
            }
            // 资源不可用，须重试。比如出现在非阻塞操作中。
            else if(errno == EAGAIN)
            {
                fprintf(stderr, "accept: errno == EAGAIN\n");
                break;                
            }
            // 文件描述符值过大==建立连接过多，资源不够
            else if(errno == EMFILE)
            {
                fprintf(stderr, "accept: errno == EMFILE\n");
                continue;              
            }
            else
            {
                fprintf(stderr, "accept error\n");
                exit(1);              
            }
        }
        else
        {
            // accept succ
            // TODO 添加心跳机制
            // TODO 添加消息队列机制
            // TODO 回显业务
            int writed = 0;
            const char* data = "hello Lars!\n";
            do
            {
                writed = write(connfd, data, strlen(data) + 1);
            }while(writed == -1 && errno == EINTR);
            // write succ
            if(writed > 0)
            {
                printf("write succ!\n");
            }

        }
        // 2-回显业务
    }
}

//析构函数 资源释放
tcp_server::~tcp_server()
{
    close(_sockfd);
}