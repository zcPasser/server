#pragma once

#include <netinet/in.h>
#include "event_loop.h"
#include "tcp_conn.h"
#include "message.h"

class tcp_server
{
public:
    //构造函数
    tcp_server(event_loop * loop, const char*ip, uint16_t port);
    //开始提供 创建连接的服务
    void do_accept();

    //析构函数 资源释放
    ~tcp_server();
private:
    //套接字 lfd
    int _sockfd;
    // 客户端连接地址
    struct sockaddr_in _connaddr;
    // 客户端连接地址 长度
    socklen_t _addrlen;

    // event_loop epoll的多路IO复用机制
    event_loop* _loop;

public:
    // 在线连接集合
    static tcp_conn * * conns;
    // 操作
    static void add_conn(int connfd, tcp_conn* conn);
    static void delete_conn(int connfd);
    static void get_conn_nums(int * curr_conn);

    static pthread_mutex_t _conns_mutex;
// 从配置文件中读的 TODO
#define MAX_CONNS 3
    // 当前允许连接 的 最大个数
    static int _max_conns;
    // 当前连接 刻度
    static int _curr_conns;

    // 路由分发机制 句柄
    static msg_router router;
    // 添加 路由的 方法
    void add_msg_router(int msgid, msg_callback cb, void *user_data=nullptr)
    {
        router.register_msg_router(msgid, cb, user_data);
    }
};

