#pragma once

void lars_hello();