#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <strings.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>

#include "tcp_server.h"
#include "reactor_buf.h"

void lars_hello()
{
    std::cout << "lars Hello!" << std::endl;
}

//构造函数
tcp_server::tcp_server(const char*ip, uint16_t port)
{
    // 优化：0
    // 0-忽略一些信号 SIGHUP SIGPIPE
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR)
    {
        // fprintf(stderr, "signal ignore SIGHUP failed\n");
        perror("signal ignore SIGHUP");
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    {
        // fprintf(stderr, "signal ignore SIGPIPE failed\n");
        perror("signal ignore SIGPIPE");
    }
    // 1-创建socket
    // SOCK_CLOEXEC：连接关闭时，释放资源。
    _sockfd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (_sockfd == -1)
    {
        fprintf(stderr, "tcp::server : socket()\n");
        exit(1);
    }
    // 2-初始化服务器地址
    struct sockaddr_in server_addr;
    // 清空
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_aton(ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);
    // 优化：2.5
    // 2.5-设置 socket 可以重复监听
    int reused_addr = 1;
    if(setsockopt(_sockfd, SOL_SOCKET, SO_REUSEADDR, &reused_addr, sizeof(reused_addr)) < 0)
    {
        // fprintf(stderr, "setsockopt reused_addr failed\n");
        perror("setsockopt reused_addr");        
    }
    // 3-绑定端口
    if (bind(_sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("bind");
        exit(1);
    }
    // 4-监听
    if (listen(_sockfd, 500) == -1)
    {
        fprintf(stderr, "bind error\n");
        exit(1);
    }
}

//开始提供 创建连接的服务
void tcp_server::do_accept()
{
    int connfd;
    // while(1)
    while(true)
    {
        // 1-accept
        connfd = accept(_sockfd, (struct sockaddr*)&_connaddr, &_addrlen);
        if(connfd == -1)
        {
            // 中断错误，合法。
            if(errno == EINTR)
            {
                fprintf(stderr, "accept: errno == EINTR\n");
                continue;
            }
            // 资源不可用，须重试。比如出现在非阻塞操作中。
            else if(errno == EAGAIN)
            {
                fprintf(stderr, "accept: errno == EAGAIN\n");
                break;                
            }
            // 文件描述符值过大==建立连接过多，资源不够
            else if(errno == EMFILE)
            {
                fprintf(stderr, "accept: errno == EMFILE\n");
                continue;              
            }
            else
            {
                fprintf(stderr, "accept error\n");
                exit(1);              
            }
        }
        else
        {
            // accept succ
            // TODO 添加心跳机制
            // TODO 添加消息队列机制
            // TODO 回显业务

            // 写一个 回显业务：回显客户端数据
            int ret = 0;
            input_buf ibuf;
            output_buf obuf;

            char * msg = nullptr;
            int msg_len = 0;

            
            do
            {
                // 将数据读到 input_buf
                ret = ibuf.read_data(connfd);
                if(ret == -1)
                {
                    fprintf(stderr, "ibuf read_data error\n");
                    break;
                }

                // 将 ibuf中数据 进行 业务处理
                msg_len = ibuf.length();
                msg = (char*) malloc(msg_len);
                bzero(msg, msg_len);
                memcpy(msg, ibuf.data(), msg_len);

                ibuf.pop(msg_len);
                ibuf.adjust();

                printf("recv data = %s\n", msg);

                // 将数据写到 output_buf
                obuf.send_data(msg, msg_len);
                while(obuf.length())
                {
                    int write_ret = obuf.write2fd(connfd);
                    if(write_ret == -1)
                    {
                        fprintf(stderr, "obuf write2fd error\n");
                        return;
                    }
                    else if(write_ret == 0)
                    {
                        // 表示 非阻塞，当前fd不可写,但并不是错误，稍后回来再写。
                        // continue; 如果不停出现问题，会不停在该循环。
                        break;
                    }
                }

                free(msg);

            }while(ret != 0);

            // 对点 客户端 已经 正常关闭。
            close(connfd);

            // ======= example =======
            // int writed = 0;
            // const char* data = "hello Lars!\n";
            // do
            // {
            //     writed = write(connfd, data, strlen(data) + 1);
            // }while(writed == -1 && errno == EINTR);
            // // write succ
            // if(writed > 0)
            // {
            //     printf("write succ!\n");
            // }

        }
    }
}

//析构函数 资源释放
tcp_server::~tcp_server()
{
    close(_sockfd);
}