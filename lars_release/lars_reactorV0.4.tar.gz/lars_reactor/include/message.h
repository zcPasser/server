#pragma once

// 解决 tcp 粘包问题的 消息封装头
struct msg_head{
    // 当前消息类型
    int msgid;
    // 消息头长度
    int msglen;
};

// 消息头长度，固定值
#define MESSAGE_HEAD_LEN 8
// 消息头 + 消息体 最大长度限制
#define MESSAGE_LENGTH_LIMIT (65535 - MESSAGE_HEAD_LEN)
