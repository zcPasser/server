#pragma once
#include "event_loop.h"
#include "reactor_buf.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

class tcp_client;

typedef void (*msg_callback)(const char*data, uint32_t len, int msgid, tcp_client*client, void*user_data);

class tcp_client
{
public:
    tcp_client(event_loop*loop, const char*ip, unsigned short port, const char* name);
    // 发送方法
    int send_message(const char*data, int msglen, int msgid);
    // 处理读业务
    void do_read();
    // 处理写业务
    void do_write();
    // 释放连接
    void clean_conn();
    // 连接服务器
    void do_connect();
    // 设置 业务处理的 回调函数
    void set_msg_callback(msg_callback msg_cb)
    {
        this->_msg_callback = msg_cb;
    }
    ~tcp_client();

    input_buf _ibuf;
    output_buf _obuf;
    // server端 IP
    struct sockaddr_in _server_addr;
    socklen_t _addrlen;
private:
    int _sockfd;

    // 客户端 事件 处理机制
    event_loop* _loop;
    // 处理 服务器消息的 回调业务函数
    msg_callback _msg_callback;

    const char* _name;
};